﻿using SGE.Aplicacion;
using SGE.Repositorios;

//Dependencias
ITramiteRepositorio repoTramite = new TramiteRepositorio();
IExpedienteRepositorio repoExpediente = new ExpedienteRepositorio();
IServicioAutorizacion serAuto = new ServicioAutorizacionProvisorio();

//Validadores
ExpedienteValidador validExp = new ExpedienteValidador();
TramiteValidador validTra = new TramiteValidador();

//Casos de uso de Expedientes
var bajaExp = new CasoDeUsoExpedienteBaja(repoExpediente,serAuto);
var altaExp = new CasoDeUsoExpedienteAlta(repoExpediente,validExp,serAuto);
var modExp = new CasoDeUsoExpedienteModificacion(repoExpediente,serAuto);
var consultaPorIdExp = new CasoDeUsoExpedienteConsultaPorId(repoExpediente);
var consultaTodosExp = new CasoDeUsoExpedienteConsultaTodos(repoExpediente);

//Casos de uso de Tramites
var bajaTra = new CasoDeUsoTramiteBaja(repoTramite,serAuto);
var altaTra = new CasoDeUsoTramiteAlta(repoTramite,validTra,serAuto);
var modTra = new CasoDeUsoTramiteModificacion(repoTramite,serAuto);
var consultaPorEtiquetaTra = new CasoDeUsoTramiteConsultaPorEtiqueta(repoTramite);
//PRUEBA DE ALTAS
//Carga Expedientes
altaExp.Ejecutar(new Expediente(1,"Caratula 1",14,EstadoExpediente.RecienIniciado));
altaExp.Ejecutar(new Expediente(2,"Caratula 2",13,EstadoExpediente.ParaResolver));                     
altaExp.Ejecutar(new Expediente(3,"Caratula 3",13,EstadoExpediente.RecienIniciado));
altaExp.Ejecutar(new Expediente(1,"Caratula 4",14,EstadoExpediente.ParaResolver));
altaExp.Ejecutar(new Expediente(4,"Caratula 5",31,EstadoExpediente.RecienIniciado));
altaExp.Ejecutar(new Expediente(5,"Caratula 6",14,EstadoExpediente.ParaResolver));
//Carga Tramites
altaTra.Ejecutar(new Tramite(1,EtiquetaTramite.EscritoPresentado,"un Contenido",1));                
altaTra.Ejecutar(new Tramite(1,EtiquetaTramite.PaseaEstudio,"un Contenido",1));                    
altaTra.Ejecutar(new Tramite(2,EtiquetaTramite.EscritoPresentado,"un Contenido",1));              
altaTra.Ejecutar(new Tramite(3,EtiquetaTramite.Notificacion,"un Contenido",1));
altaTra.Ejecutar(new Tramite(4,EtiquetaTramite.Notificacion,"un ConCUATROtenido",1));
altaTra.Ejecutar(new Tramite(5,EtiquetaTramite.EscritoPresentado,"un ContCINCOenido",1));                   
//Console.WriteLine("ALTAS EN FUNCIONAMIENTO");

//PRUEBA DE BAJAS
bajaTra.Ejecutar(1,12);
bajaTra.Ejecutar(2,12);
bajaTra.Ejecutar(3,12);
bajaTra.Ejecutar(4,12);
bajaTra.Ejecutar(6,12);
Console.WriteLine("BAJAS EN FUNCIONAMIENTO");
//PRUEBA MODIFICACIONES
Expediente ejemplo = new Expediente();
ejemplo._id = 3;
ejemplo._caratula = "------------------------------------------------CARATULA MODIFICADA-------------------------------------------------------";
ejemplo._usuarioID = 10;
ejemplo._estado = EstadoExpediente.Finalizado;
modExp.Ejecutar(ejemplo);

Tramite ejemploTramite = new Tramite();
ejemploTramite._contenido = "------------------------------------------CONTENIDO MODIFICADO-----------------------------------------------------";
ejemploTramite._id = 5;
ejemploTramite._usuarioID = 11;
modTra.Ejecutar(ejemploTramite);
Console.WriteLine("MODIFICACIONES EN FUNCIONAMIENTO.");
//PRUEBA FUNCIONES DE LOS METODOS 
List<object> EjemploFunciones =  consultaPorIdExp.Ejecutar(1);                               //devuelve una lista del expediente y sus tramites
for(int i=0; i<EjemploFunciones.Count; i++){
    Console.WriteLine(EjemploFunciones[i].ToString());
}
Console.WriteLine("CONSULTA EXPEDIENTES POR ID EN FUNCIONAMIENTO");
List<Expediente> EjemploFunciones1 = consultaTodosExp.Ejecutar(3);
for(int i=0; i<EjemploFunciones1.Count; i++){
   Console.WriteLine(EjemploFunciones1[i].ToString());
}
Console.WriteLine("CONSULTA TODOS LOS EXPEDIENTES CON UN ID ESPECIFICO EN FUNCIONAMIENTO");
List<Tramite> EjemploFunciones2 = consultaPorEtiquetaTra.Ejecutar(EtiquetaTramite.EscritoPresentado);
for(int i=0; i<EjemploFunciones2.Count; i++){
   Console.WriteLine(EjemploFunciones2[i].ToString());
}
Console.WriteLine("CONSULTA TRAMITE POR ID EN FUNCIONAMIENTO ");


