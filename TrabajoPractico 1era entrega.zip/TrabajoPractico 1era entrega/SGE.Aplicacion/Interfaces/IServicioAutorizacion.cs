namespace SGE.Aplicacion;
public interface IServicioAutorizacion {
     bool PoseeElPermiso(int idUsuario);

}