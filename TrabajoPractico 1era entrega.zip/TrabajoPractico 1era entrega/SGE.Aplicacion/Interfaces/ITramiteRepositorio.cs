namespace SGE.Aplicacion;
public interface ITramiteRepositorio{
     void AgregaTramite(Tramite unTramite);
     void EliminaTramite(int identificacionTramite);
     void EliminaTramitesPorExp(int idExpe);
     void ModificaTramite(Tramite unTramite);
     List<Tramite> ConsultaPorEtiqueta(EtiquetaTramite eti);
     void DevuelveTramites(int id,List<object> ele);
     EtiquetaTramite DevuelveEtiqueta(int IDexpediente);
}