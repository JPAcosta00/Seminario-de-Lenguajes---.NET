namespace SGE.Aplicacion;
public class ServicioAutorizacionProvisorio : IServicioAutorizacion{
    public bool PoseeElPermiso(int iden){
        return (iden  > 0);
    }
}