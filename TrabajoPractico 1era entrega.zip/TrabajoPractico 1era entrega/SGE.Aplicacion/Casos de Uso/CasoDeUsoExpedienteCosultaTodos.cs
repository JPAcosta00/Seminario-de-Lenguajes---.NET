namespace SGE.Aplicacion;


public class CasoDeUsoExpedienteConsultaTodos(IExpedienteRepositorio repo){
    public List<Expediente> Ejecutar(int idn){
       return  repo.ConsultaTodos(idn);
    }

}