namespace SGE.Aplicacion;


public class CasoDeUsoTramiteBaja(ITramiteRepositorio repo, IServicioAutorizacion servicio){
    public void Ejecutar(int identiTramite, int identiUsuario){             
        if(!servicio.PoseeElPermiso(identiUsuario)){                        //ve si el usuario tiene autorizacion
            throw new AuthorizationException("El usuario que intenta realizar la operacion no tiene los permisos necesarios.");
        }
        repo.EliminaTramite(identiTramite);
    }
    public void Ejecutar2(int idExpediente, int idUsuario){
        if(!servicio.PoseeElPermiso(idUsuario)){                        //ve si el usuario tiene autorizacion
            throw new AuthorizationException("El usuario que intenta realizar la operacion no tiene los permisos necesarios.");
        }
        repo.EliminaTramitesPorExp(idExpediente);
    }
}