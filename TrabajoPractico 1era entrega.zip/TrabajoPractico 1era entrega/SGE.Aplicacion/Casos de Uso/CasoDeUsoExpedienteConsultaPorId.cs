namespace SGE.Aplicacion;


public class CasoDeUsoExpedienteConsultaPorId(IExpedienteRepositorio repo){
    public List<object> Ejecutar(int iden){
        return  repo.ConsultaPorId(iden);
    }
}