namespace SGE.Aplicacion;
public class CasoDeUsoExpedienteModificacion(IExpedienteRepositorio repo,IServicioAutorizacion serAuto){
   
    public void Ejecutar(Expediente expe){
        if(!serAuto.PoseeElPermiso(expe._usuarioID)){                   //ve si esta autorizado el usuario
            throw new AuthorizationException("El usuario que intenta realizar la operacion no tiene los permisos necesarios.");
        }
        expe._ultimaModificacion = DateTime.Now;
        repo.ModificarExpediente(expe);
  
    }
}