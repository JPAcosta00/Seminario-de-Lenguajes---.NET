namespace SGE.Aplicacion;

public class CasoDeUsoExpedienteAlta(IExpedienteRepositorio repo, ExpedienteValidador valid,IServicioAutorizacion autoEx){
    
    public void Ejecutar(Expediente expe){
       if(!autoEx.PoseeElPermiso(expe._usuarioID)){                        //Ve si esta autorizado el usuario
            throw new AuthorizationException("El usuario que intenta realizar la operacion no tiene los permisos necesarios.");
       }
       if(!valid.Validar(expe, out string mensajeError)){                  //Ve si es valido el expediente a agregar
           throw new ValidacionException(mensajeError);
       }
       expe._creacion = DateTime.Now;
       expe._ultimaModificacion = DateTime.Now;
       repo.AgregarExpediente(expe);
    }
}