namespace SGE.Aplicacion;


public class CasoDeUsoExpedienteBaja(IExpedienteRepositorio repo,IServicioAutorizacion servicio){
    
    public void Ejecutar(int idenEx,int usuario){
        if(!servicio.PoseeElPermiso(usuario)){                          //Ve si esta autorizado el usuario
          throw new AuthorizationException("El usuario que intenta realizar la operacion no tiene los permisos necesarios.");
        }
        repo.EliminarExpediente(idenEx);
         
    }
}