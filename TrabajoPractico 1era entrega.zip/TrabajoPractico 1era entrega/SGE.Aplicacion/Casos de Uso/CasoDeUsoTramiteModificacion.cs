namespace SGE.Aplicacion;

public class CasoDeUsoTramiteModificacion(ITramiteRepositorio repo, IServicioAutorizacion seAuto){
    public void Ejecutar(Tramite tra){ 
        if(!seAuto.PoseeElPermiso(tra._usuarioID)){                   //ve si el usuario tiene autorizacion
            throw new AuthorizationException("El usuario que intenta realizar la operacion no tiene los permisos necesarios.");
        }
        tra._ultimaModificacion = DateTime.Now;
        repo.ModificaTramite(tra);
    }

}