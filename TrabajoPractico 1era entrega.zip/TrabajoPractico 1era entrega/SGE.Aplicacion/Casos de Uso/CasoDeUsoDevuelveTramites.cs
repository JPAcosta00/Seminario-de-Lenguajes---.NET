namespace SGE.Aplicacion;
public class CasoDeUsoDevuelveTramites(ITramiteRepositorio repo){
    public void Ejecutar(int identificacion,List<object> unaLista){
        repo.DevuelveTramites(identificacion,unaLista);
    }

}