namespace SGE.Aplicacion;


public class CasoDeUsoTramiteAlta(ITramiteRepositorio repo, TramiteValidador valida,IServicioAutorizacion serviA){
    public void Ejecutar(Tramite tra){
        if(!serviA.PoseeElPermiso(tra._usuarioID)){                       //ve si el usuario tiene autorizacion
            throw new AuthorizationException("El usuario que intenta realizar la operacion no tiene los permisos necesarios.");
        }
        if(!valida.Validar(tra, out string mensajeError)){                  //ve si el tramite es valido
            throw new ValidacionException(mensajeError);
        }
       tra._creacion = DateTime.Now;
       tra._ultimaModificacion = DateTime.Now;
       repo.AgregaTramite(tra);
    }
}