namespace SGE.Aplicacion;

public class CasoDeUsoDevuelveEtiqueta(ITramiteRepositorio repoT){

    public EtiquetaTramite Ejecutar(int expeID){
        EtiquetaTramite retorno =  repoT.DevuelveEtiqueta(expeID);
        return retorno;
    }

}