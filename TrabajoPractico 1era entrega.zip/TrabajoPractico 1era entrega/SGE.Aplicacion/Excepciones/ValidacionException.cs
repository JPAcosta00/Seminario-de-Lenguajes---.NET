namespace SGE.Aplicacion;
public class ValidacionException :Exception{
    public ValidacionException(string msjError) : base(msjError){ 
    }
 
}