namespace SGE.Aplicacion;
public class ExpedienteValidador{

    public bool Validar(Expediente unExpediente, out string mensajeError){
        mensajeError = " ";
        if(string.IsNullOrWhiteSpace(unExpediente._caratula)){
            mensajeError = "Caratula de la excepcion vacia.";
        }
        if(unExpediente._usuarioID <= 0){
            mensajeError += "Numero de usuario invalido";
        }
        return (mensajeError == " ");
    }
}