namespace SGE.Aplicacion;
public class TramiteValidador{
    public bool Validar(Tramite unTramite, out string mensajeError){
        mensajeError = " ";
        if(string.IsNullOrWhiteSpace(unTramite._contenido)){
            mensajeError = "Contenido del tramite vacio";
        }
        if(unTramite._usuarioID <= 0){
            mensajeError += "Numero de usuario invalido";
        }
        return (mensajeError == " ");
    }
}