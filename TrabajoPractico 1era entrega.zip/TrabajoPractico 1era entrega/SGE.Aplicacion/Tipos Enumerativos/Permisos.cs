namespace SGE.Aplicacion;

enum Permisos{
    ExpedienteAlta,
    ExpedienteBaja,
    ExpedienteModificacion,
    TramiteAlta,
    TramiteBaja,
    TramiteModificacion
}