namespace SGE.Aplicacion;

public enum EtiquetaTramite{
    EscritoPresentado,
    PaseaEstudio,
    Despacho, 
    Resolucion,
    Notificacion,
    PaseAlArchivo
}