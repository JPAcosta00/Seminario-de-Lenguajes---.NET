namespace SGE.Aplicacion;

public class Expediente {
    public int _id {get; set;} 
    public int _tramiteID {get; set;} 
    public string _caratula {get; set;} = " ";
    public DateTime _creacion {get; set;}
    public DateTime _ultimaModificacion {get; set;}
    public int _usuarioID {get; set;}
    public EstadoExpediente _estado {get; set;}
    public Expediente (){
        
    }
    public Expediente(int idTramite, string unaCaratula,int unIDusuario,EstadoExpediente unEstado){
        _tramiteID = idTramite;
        _caratula = unaCaratula;
        _usuarioID = unIDusuario;
        _estado = unEstado;
    }
    public override string ToString(){
        return ($"ID: {_id} \n ID Tramite: {_tramiteID} \n Caratula: {_caratula} \n Hora y Fecha de Creacion: {_creacion} \n Hora y Fecha de la Ultima Modificacion: {_ultimaModificacion} \n Usuario que Realizo la ultima modificacion: {_usuarioID} \n Estado del Expediente: {_estado}");
    }

}