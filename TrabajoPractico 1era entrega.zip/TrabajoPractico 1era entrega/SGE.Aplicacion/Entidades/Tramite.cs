namespace SGE.Aplicacion;

public class Tramite{
    public int _id {get; set;}
    public int _expedienteID {get; set;}
    public EtiquetaTramite _etiqueta {get; set;}
    public string _contenido {get; set;} = " ";
    public DateTime _creacion {get; set;}
    public DateTime _ultimaModificacion {get; set;}
    public int _usuarioID {get; set;}
    public Tramite(){ }
    public Tramite ( int unIDexpediente, EtiquetaTramite unaEtiqueta,string unContenido, int unIDusuario){
        _expedienteID = unIDexpediente;
        _etiqueta = unaEtiqueta;
        _contenido = unContenido;
        _usuarioID = unIDusuario;
    }
    public override string ToString(){
        return ($"ID: {_id} \n ID Expediente: {_expedienteID} \n Etiqueta: {_etiqueta} \n Contenido: {_contenido} \n Fecha y Hora de creacion: {_creacion} \n Fecha y Hora de la ultima modificacion: {_ultimaModificacion} \n Usuario que realizo la ultima modificacion: {_usuarioID}");
    }
}