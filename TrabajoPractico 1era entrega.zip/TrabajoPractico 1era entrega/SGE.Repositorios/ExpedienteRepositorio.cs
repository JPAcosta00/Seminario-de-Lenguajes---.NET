﻿namespace SGE.Repositorios;
using SGE.Aplicacion;
public class ExpedienteRepositorio : IExpedienteRepositorio{
    private string _nombreArchivo = "Expedientes.txt";
    public int _contadorIDs {get; set;} = 0;
    public void AgregarExpediente(Expediente unExpediente){
        _contadorIDs++;
        unExpediente._id = _contadorIDs;
        using var sw = new StreamWriter(_nombreArchivo,true);
        sw.WriteLine(unExpediente._id);
        sw.WriteLine(unExpediente._tramiteID);
        sw.WriteLine(unExpediente._caratula);
        sw.WriteLine(unExpediente._creacion);
        sw.WriteLine(unExpediente._ultimaModificacion);
        sw.WriteLine(unExpediente._usuarioID);
        sw.WriteLine(unExpediente._estado);
        sw.Close();
       // Console.WriteLine("Agrego Expediente ............................................. \n  " + unExpediente.ToString());
       
    }

    private void leeExpediente(in StreamReader sr,out Expediente expe){
        Expediente nuevo = new Expediente();
        nuevo._id = int.Parse(sr.ReadLine()?? " ");
        nuevo._tramiteID = int.Parse(sr.ReadLine() ?? " ");
        nuevo._caratula = sr.ReadLine()?? " ";
        nuevo._creacion = DateTime.Parse(sr.ReadLine()?? " ");
        nuevo._ultimaModificacion = DateTime.Parse(sr.ReadLine()?? " ");
        nuevo._usuarioID = int.Parse(sr.ReadLine() ?? " ");
        nuevo._estado = (EstadoExpediente) Enum.Parse(typeof(EstadoExpediente),sr.ReadLine()?? " ");
        expe = nuevo;
    }

    private void ReEscribe(List<Expediente> lis){
        using var sw = new StreamWriter(_nombreArchivo,false);
        sw.Write(string.Empty);
        for(int i=0; i < lis.Count; i++){
            sw.WriteLine(lis[i]._id);
            sw.WriteLine(lis[i]._tramiteID);
            sw.WriteLine(lis[i]._caratula);
            sw.WriteLine(lis[i]._creacion);
            sw.WriteLine(lis[i]._ultimaModificacion);
            sw.WriteLine(lis[i]._usuarioID);
            sw.WriteLine(lis[i]._estado);
        }
        sw.Close();
    }
    public void EliminarExpediente(int iden){
        using var sr = new StreamReader(_nombreArchivo,true);
        List<Expediente> listaAuxiliar = [ ];
        Expediente aux = new Expediente();
        int auxID = 0;
        int usuario= 0;
        bool encontro = false;
        while(!sr.EndOfStream){
            leeExpediente(sr, out aux);
            if(aux._id != iden){
              listaAuxiliar.Add(aux);
            }else{                                                         //si no es distinto, lo encontro
               encontro = true;                                        
               usuario = aux._usuarioID;
               auxID = aux._tramiteID;
            }
        }
        sr.Close();
        this.ReEscribe(listaAuxiliar);

        ITramiteRepositorio ITra = new TramiteRepositorio();
        IServicioAutorizacion ISer = new ServicioAutorizacionProvisorio();
        var eliminarT = new CasoDeUsoTramiteBaja(ITra,ISer);
        eliminarT.Ejecutar2(auxID,usuario);                                             //manda a eliminar los tramites de ese expediente con el id de usuario


        if(encontro == false){
            throw new RepositorioException("El expediente que se quiere eliminar no existe en el repositorio.");
        }
      
    }

    private void EliminarExpedienteModificado(int iden){                              //SOLO ELIMINA EL EXPEDIENTE QUE SE MODIFICO PARA DESPUES AGREGARLO
        using var sr = new StreamReader(_nombreArchivo,true);
        List<Expediente> listaAuxiliar = [ ];
        Expediente aux = new Expediente();
        while(!sr.EndOfStream){
            leeExpediente(sr, out aux);
            if(aux._id != iden){
              listaAuxiliar.Add(aux);
            }
        }
        sr.Close();
        this.ReEscribe(listaAuxiliar);

    }

    private void AgregaModificado(Expediente unE){                                           //Uso este modulo distinto de agregar para que siga manteniendo el mismo id 
        using var sw = new StreamWriter(_nombreArchivo,true);
        sw.WriteLine(unE._id);
        sw.WriteLine(unE._tramiteID);
        sw.WriteLine(unE._caratula);
        sw.WriteLine(unE._creacion);
        sw.WriteLine(unE._ultimaModificacion);
        sw.WriteLine(unE._usuarioID);
        sw.WriteLine(unE._estado);
        sw.Close();
    }
    
    public void ModificarExpediente(Expediente unExpediente){                  //sobre escribe el expediente, lo busca, lo elimina y lo escribe con la modificacion pasada por parametro
        using var sr = new StreamReader(_nombreArchivo,true);
        Expediente aux = new Expediente();
        bool control = true;
        bool encontro = false;
        while((!sr.EndOfStream)&&(control)){
            leeExpediente(sr,out aux);
            if(aux._id == unExpediente._id){        
                control = false;                                              //corta el recorrido del archivo
                encontro = true;                                              //osea AUX = al expediente a modificar
            } 
        }
        sr.Close();
        this.EliminarExpedienteModificado(aux._id);                                      //elimina el expediente viejo
        this.AgregaModificado(unExpediente);                                  //agrega el mismo expediente pero con la modificacion.  
        
         if(encontro == false){
            throw new RepositorioException("El expediente que se quiere modificar no existe en el repositorio.");
        }

    }
    public List<Expediente> ConsultaTodos(int iden){
        List<Expediente> listaRetorno = [];
        using var sr = new StreamReader(_nombreArchivo,true);
        Expediente aux = new Expediente();
        while(!sr.EndOfStream){
            leeExpediente(sr,out aux);
            if(aux._id == iden){
                listaRetorno.Add(aux);
            }
        }
        sr.Close();
        if(listaRetorno.Count == 0){
            throw new RepositorioException("En el repositorio no existen expedientes con ese ID");
        }
        return listaRetorno;
    }
    public List<object> ConsultaPorId(int iden){                                //primero carga el expediente y despues mandar el id al repositorio del tramite a cargar los tramites en la lista.
        List<object> lista = [];
        using var sr = new StreamReader(_nombreArchivo,true);
        bool control = false;
        Expediente auxiliar = new Expediente();
        while((!sr.EndOfStream)&&(control == false)){
            leeExpediente(sr,out auxiliar);
            if(auxiliar._id == iden){
                control = true;
            }
        }
        sr.Close();

        if(control == false){
            throw new RepositorioException("El expediente que se quiere consultar por ID no existe en el repositorio.");
        }

        lista.Add(auxiliar);
        ITramiteRepositorio tr = new TramiteRepositorio();
        var devuelve = new CasoDeUsoDevuelveTramites(tr);
        devuelve.Ejecutar(auxiliar._id,lista);                                //manda al caso de uso para devolver la lista.
        return lista;
    }

}
