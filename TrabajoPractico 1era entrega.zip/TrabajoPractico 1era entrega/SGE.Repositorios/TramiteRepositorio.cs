namespace SGE.Repositorios;
using SGE.Aplicacion;
public class TramiteRepositorio : ITramiteRepositorio{
    private string _archivoTramites = "Tramites.txt";
    public int _contadorIDs {get; set;} = 0;
    public void AgregaTramite(Tramite unTramite){
        _contadorIDs++;
        unTramite._id = _contadorIDs;
        using var sw = new StreamWriter(_archivoTramites,true);
        sw.WriteLine(unTramite._id);
        sw.WriteLine(unTramite._expedienteID);
        sw.WriteLine(unTramite._etiqueta);
        sw.WriteLine(unTramite._contenido);
        sw.WriteLine(unTramite._creacion);
        sw.WriteLine(unTramite._ultimaModificacion);
        sw.WriteLine(unTramite._usuarioID);
        sw.Close();
        //Console.WriteLine("Agrego tramite ................................................. \n" + unTramite.ToString());
        
       this.actualizacionEstado(unTramite._expedienteID);
    }

    public void actualizacionEstado(int id){
        EtiquetaTramite ultimaEtiqueta = this.DevuelveEtiqueta(id);                                   //recupera la etiqueta del ultimo tramite con el id expediente
        
        ServicioActualizacionEstado actualizaEstado = new ServicioActualizacionEstado();
        Expediente auxiliar = actualizaEstado.Ejecutar(ultimaEtiqueta,id);                             //manda al servicio de actualizacion, que me retorna el expediente con su nuevo estado
        
        IExpedienteRepositorio repoExpe = new ExpedienteRepositorio();
        IServicioAutorizacion servi = new ServicioAutorizacionProvisorio();
        var modificaExp = new CasoDeUsoExpedienteModificacion(repoExpe,servi);                              //creo el caso de uso de modificacion de expediente
       
        modificaExp.Ejecutar(auxiliar);                                                                 //manda a modificar el expediente 
    }

    private void ReEscribe (List<Tramite> l){
        using var sw = new StreamWriter(_archivoTramites,false);
        sw.Write(string.Empty);
        for(int i=0; i<l.Count; i++){
            sw.WriteLine(l[i]._id);
            sw.WriteLine(l[i]._expedienteID);
            sw.WriteLine(l[i]._etiqueta);
            sw.WriteLine(l[i]._contenido);
            sw.WriteLine(l[i]._creacion);
            sw.WriteLine(l[i]._ultimaModificacion);
            sw.WriteLine(l[i]._usuarioID);
        }
        sw.Close();
    }

    private void leeTramite(StreamReader sr,out Tramite tram){
        Tramite t = new Tramite();
         t._id = int.Parse(sr.ReadLine()?? " ");
         t._expedienteID = int.Parse(sr.ReadLine()?? " "); 
         t._etiqueta = (EtiquetaTramite) Enum.Parse(typeof(EtiquetaTramite),sr.ReadLine()?? " ");
         t._contenido = sr.ReadLine()?? " ";
         t._creacion = DateTime.Parse(sr.ReadLine()?? " ");            
         t._ultimaModificacion = DateTime.Parse(sr.ReadLine()?? " ");
         t._usuarioID =  int.Parse(sr.ReadLine()?? " ");
         tram = t;
    }

    public void EliminaTramite(int identi){                                     
        using var sr = new StreamReader(_archivoTramites,true);
        List<Tramite> lista = []; 
        bool encontro = false;
        int auxiliarID = 0;
        Tramite aux = new Tramite();
        
        while(!sr.EndOfStream){
            leeTramite(sr,out aux);
            if(aux._id != identi){                                   //si no es el que quiero elimniar no hace nada
                 lista.Add(aux);                                             //escribe el tramite leido en una lista
            }else{
                encontro = true;                                            //si lo encontro 
                auxiliarID = aux._expedienteID;
            }  
        }
        sr.Close();
        this.ReEscribe(lista);
        this.actualizacionEstado(auxiliarID);                                 //le manda a actualizar el estado del expediente con el id del tramite que se borro.

        if(encontro == false){
            throw new RepositorioException("El tramite que se quiere eliminar no existe en el repositorio.");
        } 
    }

    public void EliminaTramitesPorExp(int identi){                                     
        using var sr = new StreamReader(_archivoTramites,true);
        List<Tramite> lista = []; 
        bool encontro = false;
        Tramite aux = new Tramite();
        
        while(!sr.EndOfStream){
            leeTramite(sr,out aux);
            if(aux._expedienteID != identi){                                   //si no es el que quiero elimniar no hace nada
                 lista.Add(aux);                                             //escribe el tramite leido en una lista
            }else{
                encontro = true;                                            //si lo encontro 
            }  
        }
        sr.Close();
        this.ReEscribe(lista);

        if(encontro == false){
            throw new RepositorioException("El tramite que se quiere eliminar no existe en el repositorio.");
        } 
    }

    private void AgregaModificado(Tramite unT){
       using var sw = new StreamWriter(_archivoTramites,true);
        sw.WriteLine(unT._id);
        sw.WriteLine(unT._expedienteID);
        sw.WriteLine(unT._etiqueta);
        sw.WriteLine(unT._contenido);
        sw.WriteLine(unT._creacion);
        sw.WriteLine(unT._ultimaModificacion);
        sw.WriteLine(unT._usuarioID);
        sw.Close();
    }
    public void ModificaTramite(Tramite unTramite){
        using var sr = new StreamReader(_archivoTramites,true);
        Tramite aux = new Tramite();
        bool control = true;
        bool encontro = false;
        while((!sr.EndOfStream)&&(control)){
            leeTramite(sr,out aux);
            if(aux._id == unTramite._id){                                                                      //si lo encontro
                control = false;                                                                               //corta el recorrido del archivo
                encontro = true;                                                                                //AUX = el tramite que quiero eliminar.
            }
        }
        sr.Close();
        this.EliminaTramite(aux._id);                                                                       //lo elimina usando un modulo privado, de solo para las modificaciones
        this.AgregaModificado(unTramite);                                                                          //y lo agrega modificado con el modulo privado de solo para mods.
        this.actualizacionEstado(unTramite._expedienteID);                                                            //manda a actualizar el estado del expediente del que se modifico el tramite.

        if(encontro == false){
            throw new RepositorioException("El Tramite que se quiere modificar no existe en el repositorio.");
        }
    }

    public List<Tramite> ConsultaPorEtiqueta(EtiquetaTramite e){
        List<Tramite> retorno = [];
        using var sr = new StreamReader(_archivoTramites,true);
        Tramite aux = new Tramite();
        while(!sr.EndOfStream){
            leeTramite(sr,out aux);
            if(aux._etiqueta == e){
                retorno.Add(aux);
            }
        }
        sr.Close();
        if(retorno.Count == 0){
            throw new RepositorioException("El ID del tramite que se quiere acceder no existe en el repositorio.");
        }
        return retorno;
    }

    public void DevuelveTramites(int identi,List<object> l){
        using var sr = new StreamReader(_archivoTramites,true);
        Tramite unT = new Tramite();
        while(!sr.EndOfStream){
            leeTramite(sr,out unT);
            if(unT._expedienteID == identi){
                l.Add(unT);
            }
        }
        sr.Close();
    }

    public EtiquetaTramite DevuelveEtiqueta(int expeID){
        using var sr = new StreamReader(_archivoTramites,true);
        EtiquetaTramite etiquetaRetorno = new EtiquetaTramite();
        Tramite aux = new Tramite();
        bool encontro = true;
        while(!sr.EndOfStream){
            leeTramite(sr,out aux);
            if(aux._expedienteID == expeID){                                                                      //si lo encontro
                etiquetaRetorno = aux._etiqueta;                                        
                encontro = true;
            }
        }
        sr.Close();
        if(encontro == false){
            throw new RepositorioException("El expediente que se quiere buscar no existe en el repositorio.");
        }
        return etiquetaRetorno;
    }
}